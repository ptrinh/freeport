# freeport-nostr-mcp

An MCP server that lets AI agents **search Freeport's decentralized Nostr marketplace** — ride requests, driver/provider offers, service & product posts, and reputation — by **kind, tag, and geohash radius**. Read-only; never signs or publishes; never touches encrypted DMs.

## Tools

| Tool | What it does |
|------|--------------|
| `nostr_search_intents` | Offers/requests by side + topic tags + distance radius. Decoded, expiry-filtered, sorted nearest-first. |
| `nostr_search_reputation` | Karma ratings (kind 32103) + proven deal count (kind 32104 receipt pairs) for a pubkey. |
| `nostr_get_event` | Fetch events by id. |
| `nostr_query_raw` | Arbitrary NIP-01 filter escape hatch. |

## Run

```bash
# stdio (Claude Desktop / registry self-host)
npx freeport-nostr-mcp

# hosted HTTP endpoint
PORT=8788 npm run start:http   # POST /mcp, GET /health
```

`FREEPORT_RELAYS` (comma-separated wss URLs) overrides the default relay set.

## Scalability

- **One shared `SimplePool`** — a single websocket per relay, multiplexed across all requests.
- **Short-TTL query cache + in-flight dedup** — repeated/identical agent queries collapse to one relay round-trip.
- **Stateless HTTP** — no per-session state; scale horizontally behind a load balancer (add a shared cache like Redis if you run multiple nodes).

## Geohash radius note

Nostr relay filters match tag values **exactly** — no prefix/radius operator. `nostr_search_intents` filters by topic (`#t`) at the relay and refines distance **client-side** via haversine on each post's `g` tag. To push radius filtering to the relay (`relaySideGeohash: true`), posts must carry **multi-precision geohash prefix tags**; today they carry a single precision-6 `g`, so relay-side geohash is opt-in and a no-op until publishers add prefix tags.
